import 'package:flutter/material.dart';
import '../data/my_data.dart';
class MyFunctions {
  static List<Color> getGradientColors(String colorName) {
    final hex = MyData.colorMap[colorName] ?? MyData.colorMap['Green']!;
    return [Color(hex[0]), Color(hex[1])];
  }
}