import 'package:flutter/material.dart';

class LogoWidget extends StatelessWidget {
  const LogoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.network(
        'https://tinyurl.com/3hfa26cx',
        width: 200,
        height: 100,
        fit: BoxFit.cover,
      ),
    );
  }
}
