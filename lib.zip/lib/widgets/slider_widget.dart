import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/app_controller.dart';

class SliderWidget extends StatelessWidget {
  const SliderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AppController>();

    return Obx(() {
      return Slider(
        value: controller.speed,
        onChanged: (v) => controller.setSpeed(v),
        activeColor: controller.selectedColor.value,
        inactiveColor: Colors.grey.shade300,
        min: 0.1, // slowest
        max: 1.0, // fastest
      );
    });
  }
}
