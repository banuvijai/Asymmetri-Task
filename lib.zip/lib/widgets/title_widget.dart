import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/data_controller.dart';

class TitleWidget extends StatelessWidget {
  const TitleWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final data = Get.find<DataController>().data.value;
    return Text(
      data.title,
      style: const TextStyle(
        color: Color(0xFF7D1A12),
        fontSize: 36,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}
