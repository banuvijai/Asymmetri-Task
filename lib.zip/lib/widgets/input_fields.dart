import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/app_controller.dart';

class InputField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final Function(String)? onChanged;

  const InputField({
    super.key,
    required this.label,
    required this.controller,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppController>();

    return Obx(() {
      final color = appController.selectedColor.value;

      return TextField(
        controller: controller,
        onChanged: onChanged,
        style: TextStyle(color: color, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: color),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: color),
            borderRadius: BorderRadius.circular(12),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: color, width: 2),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        cursorColor: color,
      );
    });
  }
}
