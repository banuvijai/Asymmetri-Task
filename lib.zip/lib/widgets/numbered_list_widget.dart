import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/data_controller.dart';
import '../my_functions.dart';

class NumberedListWidget extends StatelessWidget {
  const NumberedListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final data = Get.find<DataController>().data.value;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.network(
          data.tinyImageUrl,
          width: 120,
          height: 120,
          fit: BoxFit.cover,
          errorBuilder: (c, e, s) => Container(
            width: 120,
            height: 120,
            color: Colors.grey.shade300,
            alignment: Alignment.center,
            child: const Text('Image'),
          ),
        ),
        const SizedBox(height: 12),
        ...List<Widget>.generate(
          data.points.length,
          (index) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 6.0),
            child: ListItemWidget(
              index: index + 1,
              text: data.points[index],
            ),
          ),
        ),
      ],
    );
  }
}

class ListItemWidget extends StatelessWidget {
  final int index;
  final String text;

  const ListItemWidget({
    super.key,
    required this.index,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      MyFunctions.formatListEntry(index, text),
      style: const TextStyle(
        fontSize: 20,
        color: Colors.black87,
      ),
    );
  }
}
