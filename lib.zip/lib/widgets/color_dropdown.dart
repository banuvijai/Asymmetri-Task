import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/app_controller.dart';

class ColorDropdown extends StatelessWidget {
  const ColorDropdown({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AppController>();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF3EDF3),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Obx(() => DropdownButton<Color>(
        value: controller.selectedColor.value,
        underline: const SizedBox(),
        items: [
          DropdownMenuItem(value: Colors.green, child: Text('Green')),
          DropdownMenuItem(value: Colors.red, child: Text('Red')),
          DropdownMenuItem(value: Colors.blue, child: Text('Blue')),
        ],
        onChanged: (val) {
          if (val != null) controller.updateColor(val);
        },
      )),
    );
  }
}
