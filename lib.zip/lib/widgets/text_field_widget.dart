import 'package:flutter/material.dart';

class TextFieldWidget extends StatelessWidget {
  final String label;
  final Function(String) onChanged;

  const TextFieldWidget({
    super.key,
    required this.label,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.green),
        borderRadius: BorderRadius.circular(16),
      ),
      child: TextField(
        decoration: InputDecoration(
          border: InputBorder.none,
          labelText: label,
          labelStyle:
          const TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
        ),
        keyboardType: TextInputType.number,
        onChanged: onChanged,
      ),
    );
  }
}
