import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/data_controller.dart';
import '../my_functions.dart';

class WebsiteLinkWidget extends StatelessWidget {
  const WebsiteLinkWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<DataController>();
    final url = ctrl.data.value.websiteUrl;
    return RichText(
      text: TextSpan(
        text: ctrl.data.value.websiteText,
        style: const TextStyle(
          color: Colors.blue,
          fontSize: 18,
          decoration: TextDecoration.underline,
        ),
        recognizer: TapGestureRecognizer()
          ..onTap = () {
            if (MyFunctions.looksLikeHttpUrl(url)) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Would open: $url')),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Invalid URL')),
              );
            }
          },
      ),
    );
  }
}
