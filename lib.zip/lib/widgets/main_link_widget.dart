import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/data_controller.dart';
import '../my_functions.dart';

class MainLinkWidget extends StatelessWidget {
  const MainLinkWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final data = Get.find<DataController>().data.value;
    final display = MyFunctions.shortLink(data.mainLink);
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Open link: ${data.mainLink}')),
        );
      },
      child: Text(
        display,
        style: const TextStyle(
          color: Colors.blue,
          fontSize: 18,
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }
}
