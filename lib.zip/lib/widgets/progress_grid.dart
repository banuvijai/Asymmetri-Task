import 'package:flutter/material.dart';
import 'gradient_progress_widget.dart';

class ProgressGrid extends StatelessWidget {
  final int totalItems;
  final int itemsInLine;
  final Color selectedColor;
  final bool reverse;
  final double progressValue;

  const ProgressGrid({
    super.key,
    this.totalItems = 1,   // 👈 default to 1
    this.itemsInLine = 1,  // 👈 default to 1
    this.selectedColor = Colors.green,
    this.reverse = false,
    this.progressValue = 0.5,
  });

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    final int fullRows = totalItems ~/ itemsInLine;
    final int remainder = totalItems % itemsInLine;

    for (int r = 0; r < fullRows; r++) {
      rows.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(itemsInLine, (i) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: GradientProgressWidget(
                value: progressValue,
                color: selectedColor,
                reverse: reverse,
              ),
            ),
          );
        }),
      ));
    }

    if (remainder > 0) {
      rows.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(remainder, (i) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: GradientProgressWidget(
                value: progressValue,
                color: selectedColor,
                reverse: reverse,
              ),
            ),
          );
        }),
      ));
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: rows,
    );
  }
}
