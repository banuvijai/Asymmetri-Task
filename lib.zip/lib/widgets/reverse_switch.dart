import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/app_controller.dart';

class ReverseSwitchWidget extends StatelessWidget {
  const ReverseSwitchWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AppController>();
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('Reverse'),
        const SizedBox(width: 8),
        Obx(() => Switch(
          value: controller.reverse.value,
          // Switch's onChanged expects a function(bool), so controller.toggleReverse fits
          onChanged: controller.toggleReverse,
        )),
      ],
    );
  }
}
