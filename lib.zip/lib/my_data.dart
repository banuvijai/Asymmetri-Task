import 'package:flutter/material.dart';

class MyData {
  static final List<Map<String, dynamic>> colors = [
    {'name': 'Green', 'color': Colors.green},
    {'name': 'Blue', 'color': Colors.blue},
    {'name': 'Red', 'color': Colors.red},
    {'name': 'Orange', 'color': Colors.orange},
  ];
}
