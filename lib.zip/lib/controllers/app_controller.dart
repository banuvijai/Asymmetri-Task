import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'dart:async';

class AppController extends GetxController {
  RxInt totalItems = 1.obs;
  RxInt itemsInLine = 1.obs;
  Rx<Color> selectedColor = Colors.green.obs;
  RxBool reverse = false.obs;

  RxDouble progressValue = 0.0.obs;
  double speed = 0.1;

  Timer? _timer;

  @override
  void onInit() {
    super.onInit();
    _startProgress();
  }

  void _startProgress() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      progressValue.value += speed;
      if (progressValue.value > 1) {
        progressValue.value = 0;
      }
    });
  }

  // 👇 Add these methods so your widgets can call them safely

  void setTotalItems(int value) {
    totalItems.value = value < 1 ? 1 : value;
  }

  void setItemsInLine(int value) {
    itemsInLine.value = value < 1 ? 1 : value;
  }

  void setSpeed(double value) {
    speed = value * 0.05; // adjust speed scaling
  }

  void updateColor(Color color) {
    selectedColor.value = color;
  }

  void toggleReverse(bool value) {
    reverse.value = value;
  }
}
