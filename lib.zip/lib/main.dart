import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controllers/app_controller.dart';
import 'widgets/logo_widget.dart';
import 'widgets/color_dropdown_widget.dart';
import 'widgets/slider_widget.dart';
import 'widgets/text_field_widget.dart';
import 'widgets/progress_grid.dart';

void main() {
  Get.put(AppController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AppController>();
    return Scaffold(
      backgroundColor: const Color(0xFFF9F3F9),
      body: SingleChildScrollView(
        child: Obx(()=>Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const LogoWidget(),
                const SizedBox(height: 20),
                const ColorDropdownWidget(),
                const SizedBox(height: 10),
                const SliderWidget(),
                const SizedBox(height: 10),
                TextFieldWidget(
                  label: "Total Items",
                  onChanged: (val) =>
                      controller.setTotalItems(int.tryParse(val) ?? 0),
                ),
                TextFieldWidget(
                  label: "Items in Line",
                  onChanged: (val) =>
                      controller.setItemsInLine(int.tryParse(val) ?? 0),
                ),
                const SizedBox(height: 10),
                 SwitchListTile(
                  title: const Text(
                    "Reverse",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  value: controller.reverse.value,
                  onChanged: controller.toggleReverse,
                ),
                const SizedBox(height: 20),
                const ProgressGrid(),
              ],
            ),
          ),
        )),)
    );
  }
}
